<?php
include 'db_connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_reservation'])) {
    $reservationId = intval($_POST['delete_reservation']);
    $deleteQuery = "DELETE FROM Reservations WHERE reservationId = ?";
    $stmt = $connection->prepare($deleteQuery);
    $stmt->bind_param("i", $reservationId);
    $stmt->execute();
    $stmt->close();
}

$searchName = isset($_GET['search_name']) ? trim($_GET['search_name']) : '';
$query = "SELECT r.reservationId, c.customerName, c.contactInfo, r.reservationTime, 
          r.numberOfGuests, r.specialRequests
          FROM Reservations r
          JOIN Customers c ON r.customerId = c.customerId";
if (!empty($searchName)) {
    $query .= " WHERE c.customerName LIKE ?";
}

$stmt = $connection->prepare($query);
if (!empty($searchName)) {
    $searchParam = "%" . $searchName . "%";
    $stmt->bind_param("s", $searchParam);
}
$stmt->execute();
$result = $stmt->get_result();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Reservations</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <h1>Reservations List</h1>

    <form method="GET" action="view_reservations.php" style="margin-bottom: 20px;">
        <input type="text" name="search_name" placeholder="Search by customer name" value="<?php echo htmlspecialchars($searchName); ?>">
        <button type="submit" style="padding: 10px 20px; background-color: #007BFF; color: white; border-radius: 5px; border: none;">Search</button>
        <a href="view_reservations.php" style="padding: 10px 20px; background-color: #6c757d; color: white; border-radius: 5px; text-decoration: none;">Reset</a>
    </form>

    <table border="1" cellpadding="10" cellspacing="0">
        <thead>
            <tr>
                <th>Reservation ID</th>
                <th>Customer Name</th>
                <th>Contact Info</th>
                <th>Reservation Time</th>
                <th>Number of Guests</th>
                <th>Special Requests</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['reservationId']); ?></td>
                        <td><?php echo htmlspecialchars($row['customerName']); ?></td>
                        <td><?php echo htmlspecialchars($row['contactInfo']); ?></td>
                        <td><?php echo htmlspecialchars($row['reservationTime']); ?></td>
                        <td><?php echo htmlspecialchars($row['numberOfGuests']); ?></td>
                        <td><?php echo htmlspecialchars($row['specialRequests']); ?></td>
                        <td>
                            <form method="POST" style="display: inline;">
                                <button type="submit" name="delete_reservation" value="<?php echo $row['reservationId']; ?>" 
                                    style="padding: 5px 10px; background-color: #dc3545; color: white; border: none; border-radius: 5px;">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="7">No reservations found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <div style="margin-top: 20px;">
        <a href="index.php" style="text-decoration: none; padding: 10px 20px; background-color: #007BFF; color: white; border-radius: 5px;">Back to Home</a>
    </div>

</body>
</html>

<?php
$stmt->close();
$connection->close();
?>
