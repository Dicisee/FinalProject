<?php
$host = "localhost";            
$user = "root";                 
$password = "John12randy!"; 
$database = "restaurant_reservations"; 

$connection = new mysqli($host, $user, $password, $database);


