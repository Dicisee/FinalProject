<?php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Make a Reservation</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php include 'header.php'; ?>
    <h1>Make a Reservation</h1>
    <form action="process_reservation.php" method="POST">
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" placeholder="Enter your full name" required>

        <label for="contact">Contact Info:</label>
        <input type="text" id="contact" name="contact" 
               placeholder="Enter your email or phone number" 
               pattern="^([\w.%+-]+@[a-zA-Z\d.-]+\.[a-zA-Z]{2,4}|[0-9]{10,15})$" 
               title="Enter a valid email or phone number" required>

        <label for="reservation_time">Reservation Time:</label>
        <input type="datetime-local" id="reservation_time" name="reservation_time" required>

        <label for="guests">Number of Guests:</label>
        <input type="number" id="guests" name="guests" min="1" placeholder="Enter the number of guests" required>

        <label for="special_requests">Special Requests:</label>
        <textarea id="special_requests" name="special_requests" placeholder="Any specific requirements?"></textarea>

        <button type="submit">Submit Reservation</button>
    </form>
</body>
</html>
