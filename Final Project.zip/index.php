<?php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Restaurant Reservations</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        .btn {
            display: inline-block;
            text-decoration: none;
            padding: 10px 20px;
            background-color: #007BFF;
            color: white;
            border-radius: 5px;
            font-size: 16px;
            margin: 10px;
            text-align: center;
        }

        .btn:hover {
            background-color: #0056b3;
        }

        nav {
            text-align: center;
            margin: 20px 0;
        }
    </style>
</head>
<body>
    <?php include 'header.php'; ?>
    <h1>Welcome to Restaurant Portal</h1>
    <p>Book your table online easily and quickly!</p>

    <div style="text-align: center; margin: 20px 0;">
        <img src="https://hospitalitydesign.com/wp-content/uploads/2023/02/torrisi2.jpg" alt="Restaurant" style="max-width: 100%; height: auto; border-radius: 10px;">
    </div>

    <nav>
        <a href="make_reservation.php" class="btn">Make a Reservation</a>
        <a href="view_reservations.php" class="btn">View Reservations</a>
    </nav>
</body>
</html>
