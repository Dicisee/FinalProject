<?php
include 'db_connection.php';

if ($connection) {
    echo "Connected successfully!";
} else {
    echo "Failed to connect to the database.";
}
?>
