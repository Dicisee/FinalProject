<?php
//header.php
?>
<header>
    <nav>
        <a href="index.php">Home</a>
        <a href="make_reservation.php">Make a Reservation</a>
        <a href="view_reservations.php">View Reservations</a>
    </nav>
</header>
