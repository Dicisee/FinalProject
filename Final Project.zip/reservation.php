<?php
include 'db_connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $customerName = $_POST['customer_name'];
    $contactInfo = $_POST['contact_info'];
    $reservationTime = $_POST['reservation_time'];
    $numberOfGuests = $_POST['number_of_guests'];
    $specialRequests = $_POST['special_requests'];

    if (isset($db) && method_exists($db, 'addReservation')) {
        try {
            $db->addReservation($customerName, $contactInfo, $reservationTime, $numberOfGuests, $specialRequests);
            header("Location: index.php?action=viewReservations");
            exit();
        } catch (Exception $e) {
            echo "Error adding reservation: " . $e->getMessage();
        }
    } else {
        echo "Database connection or method not found.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Reservation</title>
</head>
<body>
    <h2>Make a Reservation</h2>
    <form action="index.php?action=addReservation" method="POST">
        <label for="customer_name">Name:</label>
        <input type="text" name="customer_name" id="customer_name" required>

        <label for="contact_info">Contact Info:</label>
        <input type="text" name="contact_info" id="contact_info" required>

        <label for="reservation_time">Time:</label>
        <input type="datetime-local" name="reservation_time" id="reservation_time" required>

        <label for="number_of_guests">Number of Guests:</label>
        <input type="number" name="number_of_guests" id="number_of_guests" required>

        <label for="special_requests">Special Requests:</label>
        <input type="text" name="special_requests" id="special_requests">

        <button type="submit">Reserve</button>
    </form>
</body>
</html>
