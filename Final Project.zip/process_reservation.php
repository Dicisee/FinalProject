<?php
include 'db_connection.php';

if (!isset($connection)) {
    die("Error: Database connection is not established.");
}

// Capture form data
$customerName = isset($_POST['name']) ? trim($_POST['name']) : '';
$contactInfo = isset($_POST['contact']) ? trim($_POST['contact']) : '';
$reservationTime = isset($_POST['reservation_time']) ? $_POST['reservation_time'] : '';
$numberOfGuests = isset($_POST['guests']) ? intval($_POST['guests']) : 0;
$specialRequests = isset($_POST['special_requests']) ? trim($_POST['special_requests']) : '';

// Validate required fields
if (empty($customerName) || empty($contactInfo) || empty($reservationTime) || $numberOfGuests <= 0) {
    die("Error: All fields are required, and the number of guests must be greater than zero.");
}

try {
    // Check if the customer exists
    $query = "SELECT customerId FROM Customers WHERE customerName = ? AND contactInfo = ?";
    $stmt = $connection->prepare($query);
    if (!$stmt) {
        throw new Exception("Prepare failed: " . $connection->error);
    }
    $stmt->bind_param("ss", $customerName, $contactInfo);
    $stmt->execute();
    $result = $stmt->get_result();
    $customer = $result->fetch_assoc();

    if ($customer) {
        $customerId = $customer['customerId'];
    } else {
        // Insert a new customer if they don't exist
        $query = "INSERT INTO Customers (customerName, contactInfo) VALUES (?, ?)";
        $stmt = $connection->prepare($query);
        if (!$stmt) {
            throw new Exception("Prepare failed: " . $connection->error);
        }
        $stmt->bind_param("ss", $customerName, $contactInfo);
        $stmt->execute();
        $customerId = $stmt->insert_id; // Get the new customer ID
    }

    // Insert the reservation
    $query = "INSERT INTO Reservations (customerId, reservationTime, numberOfGuests, specialRequests)
              VALUES (?, ?, ?, ?)";
    $stmt = $connection->prepare($query);
    if (!$stmt) {
        throw new Exception("Prepare failed: " . $connection->error);
    }
    $stmt->bind_param("isis", $customerId, $reservationTime, $numberOfGuests, $specialRequests);

    if ($stmt->execute()) {
        // Redirect to the reservations page on success
        header("Location: view_reservations.php?success=1");
        exit();
    } else {
        throw new Exception("Execute failed: " . $stmt->error);
    }

} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
} finally {
    // Close the statement and connection
    if (isset($stmt)) {
        $stmt->close();
    }
    $connection->close();
}
?>
